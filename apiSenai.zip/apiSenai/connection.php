<?php
function getConnection()
{
    $host = "localhost";
    $user = "root";
    $password = "";
    $db = "bancoDesafioSENAI";
    $dsn = "mysql:host=$host;dbname=$db";

    try {
        $connection = new PDO($dsn, $user, $password);
        return $connection;
    } catch (Exception $e) {
        return $e->getCode();
    }
}