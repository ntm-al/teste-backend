<?php
require 'vendor/autoload.php';
require_once 'connection.php';
require_once 'checkConsistencyDataBase.php';
header("Access-Control-Allow-Origin: *");
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

$app = new \Slim\App();

$app->get('/', function (Request $request, Response $response, array $args) {

    if (checkConsistencyDataBase())
        return $response->withJson(buildApi());
    else {
        $api = $api = [
            "status" => "error"
        ];
        return $response->withJson($api);
    }
});

$app->run();

function buildApi()
{
    require_once ('estadosBrasileiro.php');

    $coefficientNational = calculateCoefficient(getTotalAnswerYes(), getTotalStudents());

    $api = [
        "status" => "success",
        "regionals" => [],
        "national" => $coefficientNational
    ];

    for ($i = 0; $i < count($estadosBrasileiro); $i ++) {
        ARRAY_PUSH($api["regionals"], [
            "description" => $estadosBrasileiro[$i],
            "average" => getCoefficienteByRegional($estadosBrasileiro[$i])
        ]);
    }

    return $api;
}

function getCoefficienteByRegional($uf)
{
    return calculateCoefficient(getTotalAnswerYesByRegional($uf), getTotalStudentByRegional($uf));
}

function calculateCoefficient($dividend, $diviser)
{
    $calc = $dividend / $diviser * 100;
    return number_format($calc, 4);
}

function getTotalAnswerYes()
{
    // 37 = sim
    // 38 = nao
    $connection = getConnection();

    $sql = "SELECT * FROM answers where alternative_id = 37";

    $stmt = $connection->prepare($sql);

    $stmt->execute();

    $result = $stmt->fetchAll();

    return count($result);
}

function getTotalStudents()
{
    $connection = getConnection();

    $sql = "SELECT * FROM students";

    $stmt = $connection->prepare($sql);

    $stmt->execute();

    $result = $stmt->fetchAll();

    return count($result);
}

function getTotalStudentByRegional($uf)
{
    $sql = "SELECT * from students where regional = '$uf'";
    $connection = getConnection();
    $stmt = $connection->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchAll();

    return count($result);
}

function getTotalAnswerYesByRegional($uf)
{
    $sql = "SELECT  S.regional, S.id, A.student_id, A.alternative_id
    FROM students as S
    JOIN answers as A
    ON S.id = A.student_id where A.alternative_id = 37 AND S.regional = '$uf' ";
    $connection = getConnection();
    $stmt = $connection->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchAll();

    return count($result);
}