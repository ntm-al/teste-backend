<?php
require_once 'connection.php';

function checkConsistencyDataBase()
{
    $students = "SHOW TABLES LIKE 'students'";
    $answers = "SHOW TABLES LIKE 'answers'";
    
    //1049 inexistencia banco de dados
    if (getConnection() != '1049' && checkExistenceSelect($students) && checkExistenceSelect($answers))
        return true;
    else
        return false;
}

function checkExistenceSelect($sql)
{
    $connection = getConnection();

    $stmt = $connection->prepare($sql);
    $stmt->execute();

    $result = $stmt->fetchAll();

    return count($result);
}